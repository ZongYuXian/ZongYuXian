"""Workarounds for issues that should not be fixed."""


DOMAIN_OVERRIDES = {
    # https://github.com/hacs/integration/issues/2465
    "custom-components/sensor.custom_aftership": "custom_aftership"
}
