const o=o=>void 0!==o.mozHasAudio?o.mozHasAudio:void 0===o.audioTracks||Boolean(o.audioTracks?.length);export{o as m};
